/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.file.Paths;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.jar.JarFile;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Context
/*     */ {
/*     */   private final File archiveFile;
/*     */   private final File workingDir;
/*     */   private final String relativeDir;
/*     */   
/*     */   Context() {
/*  49 */     this(getSourceArchiveFile(), Paths.get(".", new String[0]).toAbsolutePath().normalize().toFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Context(File archiveFile, File workingDir) {
/*  58 */     Assert.state((isExistingFile(archiveFile) && isJarOrWar(archiveFile)), "Unable to find source archive");
/*  59 */     this.archiveFile = archiveFile;
/*  60 */     this.workingDir = workingDir;
/*  61 */     this.relativeDir = deduceRelativeDir(archiveFile.getParentFile(), this.workingDir);
/*     */   }
/*     */   
/*     */   private boolean isExistingFile(File archiveFile) {
/*  65 */     return (archiveFile != null && archiveFile.isFile() && archiveFile.exists());
/*     */   }
/*     */   
/*     */   private boolean isJarOrWar(File jarFile) {
/*  69 */     String name = jarFile.getName().toLowerCase();
/*  70 */     return (name.endsWith(".jar") || name.endsWith(".war"));
/*     */   }
/*     */   
/*     */   private static File getSourceArchiveFile() {
/*     */     try {
/*  75 */       ProtectionDomain domain = Context.class.getProtectionDomain();
/*  76 */       CodeSource codeSource = (domain != null) ? domain.getCodeSource() : null;
/*  77 */       URL location = (codeSource != null) ? codeSource.getLocation() : null;
/*  78 */       File source = (location != null) ? findSource(location) : null;
/*  79 */       if (source != null && source.exists()) {
/*  80 */         return source.getAbsoluteFile();
/*     */       }
/*  82 */       return null;
/*     */     }
/*  84 */     catch (Exception ex) {
/*  85 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static File findSource(URL location) throws IOException, URISyntaxException {
/*  90 */     URLConnection connection = location.openConnection();
/*  91 */     if (connection instanceof JarURLConnection) {
/*  92 */       return getRootJarFile(((JarURLConnection)connection).getJarFile());
/*     */     }
/*  94 */     return new File(location.toURI());
/*     */   }
/*     */   
/*     */   private static File getRootJarFile(JarFile jarFile) {
/*  98 */     String name = jarFile.getName();
/*  99 */     int separator = name.indexOf("!/");
/* 100 */     if (separator > 0) {
/* 101 */       name = name.substring(0, separator);
/*     */     }
/* 103 */     return new File(name);
/*     */   }
/*     */   
/*     */   private String deduceRelativeDir(File sourceDirectory, File workingDir) {
/* 107 */     String sourcePath = sourceDirectory.getAbsolutePath();
/* 108 */     String workingPath = workingDir.getAbsolutePath();
/* 109 */     if (sourcePath.equals(workingPath) || !sourcePath.startsWith(workingPath)) {
/* 110 */       return null;
/*     */     }
/* 112 */     String relativePath = sourcePath.substring(workingPath.length() + 1);
/* 113 */     return !relativePath.isEmpty() ? relativePath : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getArchiveFile() {
/* 121 */     return this.archiveFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getWorkingDir() {
/* 129 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getRelativeArchiveDir() {
/* 138 */     return this.relativeDir;
/*     */   }
/*     */ }


/* Location:              /home/kali/Desktop/OSWEExam/exam-connection/soapbx.jar!/lib/spring-boot-jarmode-layertools-2.5.5.jar!/org/springframework/boot/jarmode/layertools/Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */