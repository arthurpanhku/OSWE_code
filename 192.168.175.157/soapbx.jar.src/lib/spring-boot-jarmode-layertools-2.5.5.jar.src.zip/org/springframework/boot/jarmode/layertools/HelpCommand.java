/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HelpCommand
/*     */   extends Command
/*     */ {
/*     */   private final Context context;
/*     */   private final List<Command> commands;
/*     */   
/*     */   HelpCommand(Context context, List<Command> commands) {
/*  36 */     super("help", "Help about any command", Command.Options.none(), Command.Parameters.of(new String[] { "[<command]" }));
/*  37 */     this.context = context;
/*  38 */     this.commands = commands;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void run(Map<Command.Option, String> options, List<String> parameters) {
/*  43 */     run(System.out, options, parameters);
/*     */   }
/*     */   
/*     */   void run(PrintStream out, Map<Command.Option, String> options, List<String> parameters) {
/*  47 */     Command command = !parameters.isEmpty() ? Command.find(this.commands, parameters.get(0)) : null;
/*  48 */     if (command != null) {
/*  49 */       printCommandHelp(out, command);
/*     */       return;
/*     */     } 
/*  52 */     printUsageAndCommands(out);
/*     */   }
/*     */   
/*     */   private void printCommandHelp(PrintStream out, Command command) {
/*  56 */     out.println(command.getDescription());
/*  57 */     out.println();
/*  58 */     out.println("Usage:");
/*  59 */     out.println("  " + getJavaCommand() + " " + getUsage(command));
/*  60 */     if (!command.getOptions().isEmpty()) {
/*  61 */       out.println();
/*  62 */       out.println("Options:");
/*  63 */       int maxNameLength = getMaxLength(0, command.getOptions().stream().map(Command.Option::getNameAndValueDescription));
/*  64 */       command.getOptions().stream().forEach(option -> printOptionSummary(out, option, maxNameLength));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void printOptionSummary(PrintStream out, Command.Option option, int padding) {
/*  69 */     out.println(String.format("  --%-" + padding + "s  %s", new Object[] { option.getNameAndValueDescription(), option
/*  70 */             .getDescription() }));
/*     */   }
/*     */   
/*     */   private String getUsage(Command command) {
/*  74 */     StringBuilder usage = new StringBuilder();
/*  75 */     usage.append(command.getName());
/*  76 */     if (!command.getOptions().isEmpty()) {
/*  77 */       usage.append(" [options]");
/*     */     }
/*  79 */     command.getParameters().getDescriptions().forEach(param -> usage.append(" " + param));
/*  80 */     return usage.toString();
/*     */   }
/*     */   
/*     */   private void printUsageAndCommands(PrintStream out) {
/*  84 */     out.println("Usage:");
/*  85 */     out.println("  " + getJavaCommand());
/*  86 */     out.println();
/*  87 */     out.println("Available commands:");
/*  88 */     int maxNameLength = getMaxLength(getName().length(), this.commands.stream().map(Command::getName));
/*  89 */     this.commands.forEach(command -> printCommandSummary(out, command, maxNameLength));
/*  90 */     printCommandSummary(out, this, maxNameLength);
/*     */   }
/*     */   
/*     */   private int getMaxLength(int minimum, Stream<String> strings) {
/*  94 */     return Math.max(minimum, strings.mapToInt(String::length).max().orElse(0));
/*     */   }
/*     */   
/*     */   private void printCommandSummary(PrintStream out, Command command, int padding) {
/*  98 */     out.println(String.format("  %-" + padding + "s  %s", new Object[] { command.getName(), command.getDescription() }));
/*     */   }
/*     */   
/*     */   private String getJavaCommand() {
/* 102 */     return "java -Djarmode=layertools -jar " + this.context.getArchiveFile().getName();
/*     */   }
/*     */ }


/* Location:              /home/kali/Desktop/OSWEExam/exam-connection/soapbx.jar!/lib/spring-boot-jarmode-layertools-2.5.5.jar!/org/springframework/boot/jarmode/layertools/HelpCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */