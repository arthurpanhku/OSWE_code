/*    */ package org.springframework.boot.jarmode.layertools;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ListCommand
/*    */   extends Command
/*    */ {
/*    */   private Context context;
/*    */   
/*    */   ListCommand(Context context) {
/* 33 */     super("list", "List layers from the jar that can be extracted", Command.Options.none(), Command.Parameters.none());
/* 34 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void run(Map<Command.Option, String> options, List<String> parameters) {
/* 39 */     printLayers(Layers.get(this.context), System.out);
/*    */   }
/*    */   
/*    */   void printLayers(Layers layers, PrintStream out) {
/* 43 */     layers.forEach(out::println);
/*    */   }
/*    */ }


/* Location:              /home/kali/Desktop/OSWEExam/exam-connection/soapbx.jar!/lib/spring-boot-jarmode-layertools-2.5.5.jar!/org/springframework/boot/jarmode/layertools/ListCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */