/*    */ package org.springframework.boot.jarmode.layertools;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MissingValueException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String optionName;
/*    */   
/*    */   MissingValueException(String optionName) {
/* 29 */     this.optionName = optionName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 34 */     return "--" + this.optionName;
/*    */   }
/*    */ }


/* Location:              /home/kali/Desktop/OSWEExam/exam-connection/soapbx.jar!/lib/spring-boot-jarmode-layertools-2.5.5.jar!/org/springframework/boot/jarmode/layertools/MissingValueException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */