/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Command
/*     */ {
/*     */   private final String name;
/*     */   private final String description;
/*     */   private final Options options;
/*     */   private final Parameters parameters;
/*     */   
/*     */   Command(String name, String description, Options options, Parameters parameters) {
/*  53 */     this.name = name;
/*  54 */     this.description = description;
/*  55 */     this.options = options;
/*  56 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getName() {
/*  64 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getDescription() {
/*  72 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Options getOptions() {
/*  80 */     return this.options;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Parameters getParameters() {
/*  88 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void run(Deque<String> args) {
/*  96 */     List<String> parameters = new ArrayList<>();
/*  97 */     Map<Option, String> options = new HashMap<>();
/*  98 */     while (!args.isEmpty()) {
/*  99 */       String arg = args.removeFirst();
/* 100 */       Option option = this.options.find(arg);
/* 101 */       if (option != null) {
/* 102 */         options.put(option, option.claimArg(args));
/*     */         continue;
/*     */       } 
/* 105 */       parameters.add(arg);
/*     */     } 
/*     */     
/* 108 */     run(options, parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void run(Map<Option, String> paramMap, List<String> paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Command find(Collection<? extends Command> commands, String name) {
/* 125 */     for (Command command : commands) {
/* 126 */       if (command.getName().equals(name)) {
/* 127 */         return command;
/*     */       }
/*     */     } 
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final class Parameters
/*     */   {
/*     */     private final List<String> descriptions;
/*     */ 
/*     */     
/*     */     private Parameters(String[] descriptions) {
/* 141 */       this.descriptions = Collections.unmodifiableList(Arrays.asList(descriptions));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     List<String> getDescriptions() {
/* 149 */       return this.descriptions;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 154 */       return this.descriptions.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static Parameters none() {
/* 162 */       return of(new String[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static Parameters of(String... descriptions) {
/* 172 */       return new Parameters(descriptions);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final class Options
/*     */   {
/*     */     private final Command.Option[] values;
/*     */ 
/*     */ 
/*     */     
/*     */     private Options(Command.Option[] values) {
/* 185 */       this.values = values;
/*     */     }
/*     */     
/*     */     private Command.Option find(String arg) {
/* 189 */       if (arg.startsWith("--")) {
/* 190 */         String name = arg.substring(2);
/* 191 */         for (Command.Option candidate : this.values) {
/* 192 */           if (candidate.getName().equals(name)) {
/* 193 */             return candidate;
/*     */           }
/*     */         } 
/* 196 */         throw new UnknownOptionException(name);
/*     */       } 
/* 198 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isEmpty() {
/* 206 */       return (this.values.length == 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Stream<Command.Option> stream() {
/* 214 */       return Arrays.stream(this.values);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static Options none() {
/* 222 */       return of(new Command.Option[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static Options of(Command.Option... values) {
/* 232 */       return new Options(values);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final class Option
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final String valueDescription;
/*     */ 
/*     */     
/*     */     private final String description;
/*     */ 
/*     */ 
/*     */     
/*     */     private Option(String name, String valueDescription, String description) {
/* 251 */       this.name = name;
/* 252 */       this.description = description;
/* 253 */       this.valueDescription = valueDescription;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getName() {
/* 261 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getValueDescription() {
/* 270 */       return this.valueDescription;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getNameAndValueDescription() {
/* 278 */       return this.name + ((this.valueDescription != null) ? (" " + this.valueDescription) : "");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getDescription() {
/* 286 */       return this.description;
/*     */     }
/*     */     
/*     */     private String claimArg(Deque<String> args) {
/* 290 */       if (this.valueDescription != null) {
/* 291 */         if (args.isEmpty()) {
/* 292 */           throw new MissingValueException(this.name);
/*     */         }
/* 294 */         return args.removeFirst();
/*     */       } 
/* 296 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 301 */       if (this == obj) {
/* 302 */         return true;
/*     */       }
/* 304 */       if (obj == null || getClass() != obj.getClass()) {
/* 305 */         return false;
/*     */       }
/* 307 */       return this.name.equals(((Option)obj).name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 312 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 317 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static Option flag(String name, String description) {
/* 327 */       return new Option(name, null, description);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static Option of(String name, String valueDescription, String description) {
/* 338 */       return new Option(name, valueDescription, description);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/kali/Desktop/OSWEExam/exam-connection/soapbx.jar!/lib/spring-boot-jarmode-layertools-2.5.5.jar!/org/springframework/boot/jarmode/layertools/Command.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */