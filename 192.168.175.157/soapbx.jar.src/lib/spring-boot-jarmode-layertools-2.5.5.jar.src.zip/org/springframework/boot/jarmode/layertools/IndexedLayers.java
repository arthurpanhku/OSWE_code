/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IndexedLayers
/*     */   implements Layers
/*     */ {
/*  45 */   private final Map<String, List<String>> layers = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   IndexedLayers(String indexFile) {
/*  49 */     String[] lines = (String[])Arrays.<String>stream(indexFile.split("\n")).map(line -> line.replace("\r", "")).filter(StringUtils::hasText).toArray(x$0 -> new String[x$0]);
/*  50 */     List<String> contents = null;
/*  51 */     for (String line : lines) {
/*  52 */       if (line.startsWith("- ")) {
/*  53 */         contents = new ArrayList<>();
/*  54 */         this.layers.put(line.substring(3, line.length() - 2), contents);
/*     */       }
/*  56 */       else if (line.startsWith("  - ")) {
/*  57 */         contents.add(line.substring(5, line.length() - 1));
/*     */       } else {
/*     */         
/*  60 */         throw new IllegalStateException("Layer index file is malformed");
/*     */       } 
/*     */     } 
/*  63 */     Assert.state(!this.layers.isEmpty(), "Empty layer index file loaded");
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String> iterator() {
/*  68 */     return this.layers.keySet().iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLayer(ZipEntry entry) {
/*  73 */     return getLayer(entry.getName());
/*     */   }
/*     */   
/*     */   private String getLayer(String name) {
/*  77 */     for (Map.Entry<String, List<String>> entry : this.layers.entrySet()) {
/*  78 */       for (String candidate : entry.getValue()) {
/*  79 */         if (candidate.equals(name) || (candidate.endsWith("/") && name.startsWith(candidate))) {
/*  80 */           return entry.getKey();
/*     */         }
/*     */       } 
/*     */     } 
/*  84 */     throw new IllegalStateException("No layer defined in index for file '" + name + "'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static IndexedLayers get(Context context) {
/*     */     try {
/*  95 */       try (JarFile jarFile = new JarFile(context.getArchiveFile())) {
/*  96 */         Manifest manifest = jarFile.getManifest();
/*  97 */         String location = manifest.getMainAttributes().getValue("Spring-Boot-Layers-Index");
/*  98 */         ZipEntry entry = (location != null) ? jarFile.getEntry(location) : null;
/*  99 */         if (entry != null) {
/* 100 */           String indexFile = StreamUtils.copyToString(jarFile.getInputStream(entry), StandardCharsets.UTF_8);
/* 101 */           return new IndexedLayers(indexFile);
/*     */         } 
/*     */       } 
/* 104 */       return null;
/*     */     }
/* 106 */     catch (FileNotFoundException|java.nio.file.NoSuchFileException ex) {
/* 107 */       return null;
/*     */     }
/* 109 */     catch (IOException ex) {
/* 110 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/kali/Desktop/OSWEExam/exam-connection/soapbx.jar!/lib/spring-boot-jarmode-layertools-2.5.5.jar!/org/springframework/boot/jarmode/layertools/IndexedLayers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */