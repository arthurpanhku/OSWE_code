/**
 * Core JDBC implementation.
 */
@NonNullApi
package org.springframework.data.jdbc.core;

import org.springframework.lang.NonNullApi;
