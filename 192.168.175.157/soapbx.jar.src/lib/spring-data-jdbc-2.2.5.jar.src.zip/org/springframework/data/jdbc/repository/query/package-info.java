/**
 * Query derivation mechanism for JDBC specific repositories.
 */
@NonNullApi
package org.springframework.data.jdbc.repository.query;

import org.springframework.lang.NonNullApi;
