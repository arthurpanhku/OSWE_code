@NonNullApi
package org.springframework.data.jdbc.repository.support;

import org.springframework.lang.NonNullApi;
