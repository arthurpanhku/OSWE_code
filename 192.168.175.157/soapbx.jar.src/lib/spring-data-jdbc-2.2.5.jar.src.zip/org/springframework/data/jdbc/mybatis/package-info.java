@NonNullApi
package org.springframework.data.jdbc.mybatis;

import org.springframework.lang.NonNullApi;
