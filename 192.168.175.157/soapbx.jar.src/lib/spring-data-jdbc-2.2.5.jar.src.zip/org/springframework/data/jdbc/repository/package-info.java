@NonNullApi
package org.springframework.data.jdbc.repository;

import org.springframework.lang.NonNullApi;
