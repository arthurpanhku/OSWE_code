@org.springframework.lang.NonNullApi
package org.springframework.data.jdbc.core.mapping;
