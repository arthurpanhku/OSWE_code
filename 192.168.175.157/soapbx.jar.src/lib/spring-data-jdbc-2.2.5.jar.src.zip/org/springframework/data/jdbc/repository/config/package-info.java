@NonNullApi
package org.springframework.data.jdbc.repository.config;

import org.springframework.lang.NonNullApi;
