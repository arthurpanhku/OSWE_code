/**
 * JDBC-specific conversion classes.
 */
@NonNullApi
package org.springframework.data.jdbc.core.convert;

import org.springframework.lang.NonNullApi;
