@NonNullApi
package org.springframework.data.relational.core.mapping;

import org.springframework.lang.NonNullApi;
