/**
 * Query support for relational database repositories.
 */
@NonNullApi
package org.springframework.data.relational.repository.query;

import org.springframework.lang.NonNullApi;
