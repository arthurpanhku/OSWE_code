@NonNullApi
package org.springframework.data.relational.core.conversion;

import org.springframework.lang.NonNullApi;
