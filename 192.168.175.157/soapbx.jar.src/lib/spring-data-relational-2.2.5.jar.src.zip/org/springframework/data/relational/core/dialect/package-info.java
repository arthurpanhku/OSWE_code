/**
 * Dialects abstract the SQL dialect of the underlying database.
 */
@NonNullApi
package org.springframework.data.relational.core.dialect;

import org.springframework.lang.NonNullApi;
