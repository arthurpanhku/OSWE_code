/**
 * Support infrastructure for query derivation of relational database repositories.
 */
@NonNullApi
package org.springframework.data.relational.repository.support;

import org.springframework.lang.NonNullApi;
