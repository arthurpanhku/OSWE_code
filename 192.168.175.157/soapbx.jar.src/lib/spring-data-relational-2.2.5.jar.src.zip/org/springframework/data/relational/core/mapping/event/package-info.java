@NonNullApi
package org.springframework.data.relational.core.mapping.event;

import org.springframework.lang.NonNullApi;
